package com.workflow2.ecommerce.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import com.workflow2.ecommerce.entity.Review;
import org.springframework.data.jpa.repository.Query;

/**
 * @author nikhitha_sripada
 * @version v0.0.1
 */
public interface ReviewDao extends JpaRepository<Review, UUID>{

    @Query(value = "select * from review where product_id=?1", nativeQuery = true)
    public List<Review> findByProductId(UUID productId);
}
