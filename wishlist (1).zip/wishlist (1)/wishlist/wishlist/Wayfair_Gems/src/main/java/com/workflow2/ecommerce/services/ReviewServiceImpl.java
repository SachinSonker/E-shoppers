package com.workflow2.ecommerce.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.workflow2.ecommerce.dto.ReviewRequest;
import com.workflow2.ecommerce.entity.Product;
import com.workflow2.ecommerce.entity.Review;
import com.workflow2.ecommerce.repository.ProductDao;
import com.workflow2.ecommerce.repository.ReviewDao;

/**
 * @author nikhitha_sripada
 * @version v0.0.1
 */
@Service
public class ReviewServiceImpl {
    @Autowired
    private ReviewDao reviewDao;

    @Autowired
    private ProductDao productDao;

    public Review createReviews(ReviewRequest review) {
        Product product = productDao.findByProductId(review.getProductId());
        Review reviewSave = Review.builder().description(review.getDescription()).rating(review.getRating()).product(product).build();
        return reviewDao.save(reviewSave);
    }

    public List<Review> getAllReviews() {
        return reviewDao.findAll();
    }


    public List<Review> getProductReviewsById(UUID productId) {
        return reviewDao.findByProductId(productId);
    }

    public void deleteReviews(UUID reviewId) {
        reviewDao.deleteById(reviewId);
    }

    public Review editReviews(Review review1, UUID productId) throws RuntimeException {
        Optional<Review> review = reviewDao.findById(review1.getReviewId());
        if (review.isPresent()) {
            Product product = productDao.findByProductId(productId);
            review1.setProduct(product);
            return reviewDao.save(review1);
        } else {
            throw new RuntimeException("Review  is not found with the id: " + review1.getReviewId());
        }
    }

}