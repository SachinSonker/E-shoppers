package com.workflow2.ecommerce.dto;

import com.workflow2.ecommerce.entity.Product;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * This class is used to return the response for wishlist
 * @author tejas_badjate
 * @version v0.0.2
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class WishlistDTO {
    private Product product;
    private UUID wishlistId;
}
