package com.workflow2.ecommerce.controller;

import com.workflow2.ecommerce.dto.WishlistDTO;
import com.workflow2.ecommerce.entity.User;
import com.workflow2.ecommerce.services.CartServiceImpl;
import com.workflow2.ecommerce.services.WishlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.UUID;

/**
 * This Class have all the endpoints which help us to place, view and delete the wishlist product
 * @author tejas_badjate
 * @version v0.0.2
 */

@RestController
@RequestMapping(value = "/api/wishlist/")
public class WishlistController {
    @Autowired
    CartServiceImpl cartService;
    @Autowired
    WishlistService wishListService;

    /**
     * This controller method have endpoint to add product to wishlist
     * @param httpServletRequest It is the request header
     * @param productId it is used to identify which product need to add
     * @return It returns "add to wishlist" message after adding
     */
    @PostMapping("/{productId}")
    public ResponseEntity<String> addItemToWishlist(HttpServletRequest httpServletRequest, @PathVariable UUID productId){
        User user = cartService.getUser(httpServletRequest);
        return wishListService.addItemToWishList(productId,user.getId());
    }

    /**
     * This method have endpoint for get wishlist
     * @param httpServletRequest It is the request header
     * @return It returns the list of all products added to wishlist
     */
    @GetMapping("/")
    public ResponseEntity<List<WishlistDTO>> getWishlist(HttpServletRequest httpServletRequest) throws Exception {
        User user = cartService.getUser(httpServletRequest);
        return wishListService.getWishlist(user.getId());
    }

    /**
     * This method is the endpoint for removing the product from wishlist
     * @param wishlistId It helps in deleting a particular product from wishlist
     * @return It returns "removed" message
     */

    @DeleteMapping("/{wishlistId}")
    public ResponseEntity<String> deleteWishlist(@PathVariable UUID wishlistId){
        return wishListService.deleteFromWishList(wishlistId);
    }

    /**
     * This method is the endpoint for removing the product from wishlist
     * @param httpServletRequest It is the request header with the help of this we can fetch the user
     * @return It returns "removed all" message
     */

    @DeleteMapping("/")
    public  ResponseEntity<String > deleteAllWishlist(HttpServletRequest httpServletRequest){
        User user = cartService.getUser(httpServletRequest);
        return wishListService.deleteAllWishlist(user.getId());
    }

    @DeleteMapping("/{productId)")
    public ResponseEntity<String> deleteWishlistFromPDP(HttpServletRequest httpServletRequest,@PathVariable UUID productId){
        User user = cartService.getUser(httpServletRequest);
        wishListService.deleteFromPDP(user.getId(),productId);
    }
}
