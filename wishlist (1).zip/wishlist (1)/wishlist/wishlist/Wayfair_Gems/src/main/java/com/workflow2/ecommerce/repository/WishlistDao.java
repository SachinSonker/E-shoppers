package com.workflow2.ecommerce.repository;

import com.workflow2.ecommerce.entity.Wishlist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.UUID;
/**
 * This repository help us to perform all database operation on wishlist table
 * @author tejas_badjate
 * @version v0.0.2
 */
public interface WishlistDao extends JpaRepository<Wishlist,UUID> {
    @Query(value = "select * from wishlist w where w.user_id= :userId and w.product_id = :productId",nativeQuery = true)
    public Wishlist getUserByGroup(@Param(value = "userId") UUID userId, @Param(value = "productId") UUID productId);

    @Query(value = "select * from wishlist w where w.user_id = :userId",nativeQuery = true)
    public List<Wishlist> getAllWishListOfUser(UUID userId);

    public void deleteByUserIdAndProductId(UUID userId,UUID productId);
}
