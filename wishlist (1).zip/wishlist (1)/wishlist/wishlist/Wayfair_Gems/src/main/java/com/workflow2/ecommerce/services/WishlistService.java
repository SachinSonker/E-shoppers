package com.workflow2.ecommerce.services;

import com.workflow2.ecommerce.dto.WishlistDTO;

import com.workflow2.ecommerce.entity.Product;
import com.workflow2.ecommerce.entity.Wishlist;
import com.workflow2.ecommerce.repository.ProductDao;
import com.workflow2.ecommerce.repository.WishlistDao;
import com.workflow2.ecommerce.util.ImageUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * This class is the implementation of user module which contains wishlist method
 * @author tejas_badjate
 * @version v0.0.2
 */
@Service
public class WishlistService {
    @Autowired
    WishlistDao wishlistDao;
    @Autowired
    ProductDao productDao;

    /**
     * This controller method is used to add product to wishlist
     * @param userId it is the Id of the User
     * @param productId it is used to identify which product need to add
     * @return It returns "add to wishlist" message after adding
     */

    public ResponseEntity<String> addItemToWishList(UUID productId, UUID userId){
        if (wishlistDao.getUserByGroup(userId,productId) == null){
            wishlistDao.save(new Wishlist(UUID.randomUUID(),userId,productId));
            return ResponseEntity.status(HttpStatus.CREATED).body("Added to Wishlist");
        }
        return ResponseEntity.status(HttpStatus.OK).body("This product already added to Wishlist");
    }

    /**
     * This method is used to get wishlist
     * @param userId It is the Id of the user
     * @return It returns the list of all products added to wishlist
     */

    public ResponseEntity<List<WishlistDTO>> getWishlist(UUID userId) throws Exception {
        List<Wishlist> wishListList = wishlistDao.getAllWishListOfUser(userId);
        List<WishlistDTO>wishListDTOS = new ArrayList<>();
        for(Wishlist list: wishListList){
            Product product = productDao.findById(list.getProductId()).get();
            product.setImage(ImageUtility.decompressImage(product.getImage()));
            wishListDTOS.add(new WishlistDTO(product,list.getWishListId()));
        }
        return ResponseEntity.ok().body(wishListDTOS);
    }

    /**
     * This method is used for removing the product from wishlist
     * @param wishlistId It helps in deleting a particular product from wishlist
     * @return It returns "removed" message
     */

    public ResponseEntity<String> deleteFromWishList(UUID wishlistId){

        wishlistDao.deleteById(wishlistId);
        return ResponseEntity.status(HttpStatus.OK).body("Removed");
    }


    /**
     * This method is used for removing the product from wishlist
     * @param userId It is the Id of the user
     * @return It returns "removed all" message
     */

    public ResponseEntity<String> deleteAllWishlist(UUID userId) {
        List<Wishlist> wishListList = wishlistDao.getAllWishListOfUser(userId);
        for(Wishlist wishList:wishListList){
            wishlistDao.deleteById(wishList.getWishListId());
        }
        return ResponseEntity.ok().body("Removed All");
    }

    public void deleteFromPDP(UUID userId, UUID productId) {
        wishlistDao.deleteByUserIdAndProductId(userId, productId);
    }
}
