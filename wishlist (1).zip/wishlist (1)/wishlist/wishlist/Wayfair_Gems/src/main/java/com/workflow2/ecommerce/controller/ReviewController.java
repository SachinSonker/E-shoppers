package com.workflow2.ecommerce.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.workflow2.ecommerce.dto.ReviewRequest;
import com.workflow2.ecommerce.entity.Review;
import com.workflow2.ecommerce.services.ReviewServiceImpl;

/**
 * @author nikhitha_sripada
 * @version v0.0.1
 */
@RestController
@RequestMapping("/api")
public class ReviewController {

    @Autowired
    private ReviewServiceImpl reviewServiceImpl;

    @PostMapping("/createreviews")
    public ResponseEntity<Review> createReviews(@RequestBody ReviewRequest review) {
        Review createReview = reviewServiceImpl.createReviews(review);
        return ResponseEntity.status(HttpStatus.CREATED).body(createReview);
    }

    @GetMapping("/reviews")
    public ResponseEntity<List<Review>> getAllReviews() {
        return ResponseEntity.ok(reviewServiceImpl.getAllReviews());

    }

    @GetMapping("/reviews/{productId}")
    public ResponseEntity<List<Review>> getProductReviewsById(@PathVariable("productId") UUID productId) {
        return ResponseEntity.ok(reviewServiceImpl.getProductReviewsById(productId));
    }

    @DeleteMapping("/deletereviews/{reviewId}")
    public ResponseEntity<String> deleteReviews(@PathVariable("reviewId") UUID reviewId) {
        try {
            reviewServiceImpl.deleteReviews(reviewId);
            return ResponseEntity.ok("Review deleted successfully!");
        }catch (Exception e){
            return ResponseEntity.internalServerError().body("Unable to delete Review! There is some issue!");
        }
    }

    @PutMapping("/editreviews/{productId}")
    public ResponseEntity<?> editReviews(@RequestBody Review review, @PathVariable("productId") UUID productId) {
        try {
            return ResponseEntity.ok(reviewServiceImpl.editReviews(review,productId));
        }catch (RuntimeException e){
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

}
