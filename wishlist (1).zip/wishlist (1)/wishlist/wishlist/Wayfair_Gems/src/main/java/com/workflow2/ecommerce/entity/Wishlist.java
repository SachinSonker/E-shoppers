package com.workflow2.ecommerce.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.UUID;


/**
 * This class is the entity class which contains relation between user and wishlist
 * @author tejas_badjate
 * @version v0.0.2
 */
@Entity
@Table(name = "wishlist")
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Wishlist {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID wishListId;

    @Column(name = "user_id")
    private UUID userId;

    @Column(name="product_id")
    private UUID productId;
}
