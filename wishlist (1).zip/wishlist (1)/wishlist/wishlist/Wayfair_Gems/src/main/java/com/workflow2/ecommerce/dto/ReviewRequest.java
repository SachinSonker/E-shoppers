package com.workflow2.ecommerce.dto;

import java.util.UUID;

import com.workflow2.ecommerce.entity.Product;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
/**
 * @author nikhitha_sripada
 * @version v0.0.1
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ReviewRequest {

   private String description;
   private float rating;
   private UUID productId;

}
